package ParcelProject.exception;

public class ParcelReceiptException extends RuntimeException{
	public ParcelReceiptException(String message) {
		super(message);
	}
}
