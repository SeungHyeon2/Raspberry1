package ParcelProject.exception;

public class AdminManagementException extends RuntimeException{
	public AdminManagementException(String message) {
		super(message);
	}
}
