package ParcelProject.exception;

public class ParcelKeepException extends RuntimeException{
	public ParcelKeepException(String message) {
		super(message);
	}
}
